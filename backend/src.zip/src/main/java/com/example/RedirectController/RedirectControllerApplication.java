package com.example.RedirectController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedirectControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedirectControllerApplication.class, args);
	}

}
