package com.example.RedirectController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedirectControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
